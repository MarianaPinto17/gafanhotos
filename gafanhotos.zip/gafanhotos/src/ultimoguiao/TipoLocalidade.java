package ultimoguiao;

public enum TipoLocalidade {
	Aldeia, Cidade, Vila, Indefinida;
}
