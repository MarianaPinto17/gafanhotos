package aula11;

public class Visitante extends Pessoa {
	//herança pobre/implementação
}
