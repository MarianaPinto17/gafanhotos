package aula6;

public class Aula6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ControloRemoto c = new ControloRemoto();
		c.maisVolume();
		c.play();
		c.abrirMenu();
		c.fecharMenu();
		
	}

}
