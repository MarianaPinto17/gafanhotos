package aula12;

public class Cachorro extends Mamifero {
	
	@Override
	public void emitirSom() {
		System.out.println("AU AU AU");
	}
}
