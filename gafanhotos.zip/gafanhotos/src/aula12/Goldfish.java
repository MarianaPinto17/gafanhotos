package aula12;

public class Goldfish extends Peixe {
	
}
