package aula12;

public class Arara extends Ave{

}
