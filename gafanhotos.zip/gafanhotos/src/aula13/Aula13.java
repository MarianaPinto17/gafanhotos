package aula13;

public class Aula13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cachorro x = new Cachorro();
		x.emitirSom();
	}

}
